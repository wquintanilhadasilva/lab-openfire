/* The database update has been implemented in org.jivesoftware.database.bugfix.OF1515.java */
/* Update version */
UPDATE ofVersion SET version = 28 WHERE name = 'openfire';
